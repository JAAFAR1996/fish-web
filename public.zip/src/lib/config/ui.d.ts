export declare const IMAGE_DEVICE_SIZES: readonly number[];
export declare const IMAGE_SIZES: readonly number[];
