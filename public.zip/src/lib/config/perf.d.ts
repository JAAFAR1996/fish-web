export declare const MAX_SEARCH_QUERY_LENGTH: number;
export declare const MAX_PRODUCT_SUGGESTIONS: number;
export declare const SEARCH_FALLBACK_CACHE_TTL_MS: number;
