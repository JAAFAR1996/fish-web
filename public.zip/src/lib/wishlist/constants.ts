export const WISHLIST_STORAGE_KEY = 'fish-web-wishlist';

export const MAX_WISHLIST_ITEMS = 100;
