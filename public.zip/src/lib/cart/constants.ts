export const FREE_SHIPPING_THRESHOLD = 100_000;
export const MAX_QUANTITY = 99;
export const MIN_QUANTITY = 1;
export const STORAGE_KEY = 'fish-web-cart';
export const SAVED_ITEMS_KEY = 'fish-web-saved-items';
export const CART_SYNC_DEBOUNCE = 500;
